import { usePop } from "@/hooks/useFade";
import { useSwipe } from "@/hooks/useSwipe";
import React, { useLayoutEffect, useRef, useState } from "react";
import { Dimensions, View } from "react-native";

export function ShowOnSwipe({
    left,
    right,
    up,
    down,
    allDirections,
    children,
}: {
    left?: JSX.Element;
    right?: JSX.Element;
    up?: JSX.Element;
    down?: JSX.Element;
    allDirections?: JSX.Element;
    children?: React.ReactNode | React.ReactNode[];
}) {
    const swipes = {} as Record<
        keyof Omit<
            Parameters<typeof useSwipe>[0],
            "minDistance" | "maxDeviance"
        >,
        () => void
    >;

    const pops = [];

    if (allDirections) {
        const allPop = usePop(allDirections, {
            afterPopIn() {
                allPop.popOut();
            },
        });
        swipes["onSwipe"] = allPop.popIn;
        pops.push(allPop.popComponent);
    }

    if (left) {
        const leftPop = usePop(left, {
            afterPopIn() {
                leftPop.popOut();
            },
        });
        swipes["onSwipeLeft"] = leftPop.popIn;
        pops.push(leftPop.popComponent);
    }

    if (right) {
        const rightPop = usePop(right, {
            afterPopIn() {
                rightPop.popOut();
            },
        });
        swipes["onSwipeRight"] = rightPop.popIn;
        pops.push(rightPop.popComponent);
    }

    if (up) {
        const upPop = usePop(up, {
            afterPopIn() {
                upPop.popOut();
            },
        });
        swipes["onSwipeUp"] = upPop.popIn;
        pops.push(upPop.popComponent);
    }

    if (down) {
        const downPop = usePop(down, {
            afterPopIn() {
                downPop.popOut();
            },
        });
        swipes["onSwipeDown"] = downPop.popIn;
        pops.push(downPop.popComponent);
    }

    const { onTouchStart, onTouchEnd } = useSwipe(swipes);
    const [elemHeight, setHeight] = useState(0);

    return (
        <View onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
            {children}
            <View
                style={{
                    position: "absolute",
                    alignItems: "center",
                    left: 0,
                    right: 0,
                }}
            >
                {pops.map((element, i) => (
                    <View
                        style={{
                            position: "absolute",
                            zIndex: 2,
                            top:
                                Dimensions.get("window").height / 2 -
                                elemHeight / 2,
                        }}
                        onLayout={(event) => {
                            setHeight(event.nativeEvent.layout.height);
                        }}
                        key={i}
                    >
                        {element}
                    </View>
                ))}
            </View>
        </View>
    );
}
