declare module "*.ttf";
